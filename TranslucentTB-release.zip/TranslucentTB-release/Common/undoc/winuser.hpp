#pragma once
#include "../arch.h"
#include <windef.h>

static constexpr DWORD EVENT_SYSTEM_PEEKSTART = 0x0021;
static constexpr DWORD EVENT_SYSTEM_PEEKEND   = 0x0022;
