#pragma once
#include "arch.h"
#include <windef.h>

extern "C"
#ifdef EXPLORERTAP_EXPORTS
__declspec(dllexport)
#else
__declspec(dllimport)
#endif
HRESULT InjectExplorerTAP(HWND window, REFIID riid, LPVOID* ppv);

using PFN_INJECT_EXPLORER_TAP = decltype(&InjectExplorerTAP);
