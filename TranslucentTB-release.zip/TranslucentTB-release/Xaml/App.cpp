#include "pch.h"

#include "App.h"
#if __has_include("App.g.cpp")
#include "App.g.cpp"
#endif

namespace winrt::TranslucentTB::Xaml::implementation
{
	App::App()
	{
		// empty
	}
}
