#include "pch.h"

#include "BindableObjectReference.h"
#if __has_include("BindableObjectReference.g.cpp")
#include "BindableObjectReference.g.cpp"
#endif
