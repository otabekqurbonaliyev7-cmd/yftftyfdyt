#include "pch.h"

#include "Case.h"
#if __has_include("Controls/Case.g.cpp")
#include "Controls/Case.g.cpp"
#endif

namespace winrt::TranslucentTB::Xaml::Controls::implementation
{
	// everything declared in header, this file required for cppwinrt uniform construction
}
