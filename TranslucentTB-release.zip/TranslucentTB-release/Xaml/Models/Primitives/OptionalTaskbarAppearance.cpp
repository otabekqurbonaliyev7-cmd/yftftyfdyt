#include "pch.h"

#include "OptionalTaskbarAppearance.h"
#if __has_include("Models/Primitives/OptionalTaskbarAppearance.g.cpp")
#include "Models/Primitives/OptionalTaskbarAppearance.g.cpp"
#endif
